package com.exampleSms.Exception;

public class CourseResourseNoutFound extends RuntimeException
{
	private static final long serialVersionUID = 1L;

	public CourseResourseNoutFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
