package com.exampleSms.Exception;

public class TeacherResourseNoutFoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;

	public TeacherResourseNoutFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
