package com.exampleSms.Exception;

public class EducationDetailsResourseNoutFoundException extends RuntimeException{
	private static final long serialVersionUID = 1L;

	public EducationDetailsResourseNoutFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
