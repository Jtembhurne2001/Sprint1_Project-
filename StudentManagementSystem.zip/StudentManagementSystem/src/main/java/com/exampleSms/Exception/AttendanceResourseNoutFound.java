package com.exampleSms.Exception;

public class AttendanceResourseNoutFound extends RuntimeException
{
	private static final long serialVersionUID = 1L;

	public AttendanceResourseNoutFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
