package com.exampleSms.Exception;

public class TestResourseNoutFoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;

	public TestResourseNoutFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
