package com.exampleSms.Exception;

public class ReportResourseNoutFoundException extends RuntimeException
{
	private static final long serialVersionUID = 1L;

	public ReportResourseNoutFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
